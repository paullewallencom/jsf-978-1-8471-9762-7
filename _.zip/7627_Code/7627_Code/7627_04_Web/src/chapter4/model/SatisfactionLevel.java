package chapter4.model;

public enum SatisfactionLevel {

	VERY_UNSATISFIED, SOMEWHAT_UNSATISFIED, NEUTRAL, SOMEWHAT_SATISFIED, VERY_SATISFIED, ;

}
