For instructions on how to import, build, deploy, and test this example 
application, please see the document titled 7627_SetupGuide.doc in the root 
of the ZIP file named 7627_CodeBundle.zip.